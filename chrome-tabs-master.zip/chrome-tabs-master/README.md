### Chrome Tabs in Chrome

Exactly what you think this is. Go wild.

### [Demo](http://adamschwartz.co/chrome-tabs/)

![](http://adamschwartz.co/chrome-tabs/chrome-tabs.gif)

### Inspiration

I want to thank Google and these folks for the inspiration:
- http://stackoverflow.com/questions/5322895/is-there-a-way-to-create-a-chrome-like-tab-using-css
- http://www.redeyeoperations.com/wp-content/uploads/2011/08/demo_dyn.html
- http://css-tricks.com/examples/MovingHighlight/
- http://jsfiddle.net/w34nm/
- http://jsfiddle.net/a656n/
